if __name__ == "__main__":
    from core import bot

    bot.run(bot.config.DISCORD_TOKEN)
