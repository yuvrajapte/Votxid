from .scrims import ScrimEvents
from .slots import SlotManagerEvents
from .ssverify import Ssverification
from .tags import TagEvents
from .tourneys import TourneyEvents
