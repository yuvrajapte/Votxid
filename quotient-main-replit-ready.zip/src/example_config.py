# for tortoise-orm

TORTOISE = {}


POSTGRESQL = {}

EXTENSIONS = ()

DISCORD_TOKEN = "MTA3MTMxNjc5MjcyNDY5NzIwMA.GLqXqg.05ZWL0luDi5OWS4it_DU3aEk1z62ChUaHbSurc"

COLOR = 0x00FFB3

FOOTER = "inspired by quotient!"

PREFIX = "y!"

SERVER_LINK = ""

BOT_INVITE = ""

WEBSITE = ""

REPOSITORY = ""

DEVS = ()

# LOGS
SHARD_LOG = ""
ERROR_LOG = ""
PUBLIC_LOG = ""
