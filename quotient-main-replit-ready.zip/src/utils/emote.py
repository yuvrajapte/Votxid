# never ask me to remove these :c
red = "<:red:775586906599456779>"
green = "<:green:775586905580240946>"
yellow = "<:yellow:775586904439128064>"
invisible = "<:invisible:775586907680931860>"

scrimscheck = "<:scrimscheck:839554647861755946>"
scrimsxmark = "<:scrimscross:839554689778712576>"

info = "<:info2:899020593188462693>"
trash = "<:trashcan:896382424529907742>"
exit = "<:exit:926048897548300339>"


add = "<:add:844825523003850772>"
remove = "<:remove:844825861295046661>"
edit = "<:edit:844826616735727616>"

diamond = "<a:diamond:899295009289949235>"

error = "❗"

server = "<:server:775586933396078612>"
privacy = "<:privacy:775586938659799060>"

one = "1️⃣"
two = "2️⃣"
three = "3️⃣"
four = "4️⃣"
five = "5️⃣"


rps = "<:rps:833993433415811083>"


bravery = "<:bravery:833991097222299678>"
brilliance = "<:brilliance:833991154839191573>"
balance = "<:balance:833991183087829012>"

supporter = "<:supporter:833991451872198696>"
staff = "<:staff:833991411313147915>"
partner = "<:partner:833991367130087464>"
hypesquad = "<:hypesquad:833991496545206282>"
hypesquad_events = "<:hypesquad_events:833991530418667540>"
bug_hunter = "<:bug_hunter:833991572613234718>"
BugHunterLvl2 = "<:bug_hunter2:833991610357514240>"
bot = "<:bot:833991659133992991>"
bot_devloper = "<:bot_devloper:833991714637217803>"
verified_bot = "<:verifiedbot1:833991773248290817><:verifiedbot2:833991793683070996>"

check = "<:check:807913701151342592>"
xmark = "<:xmark:807913737805234176>"
loading = "<a:loading:815826684262744124>"
VoiceChannel = "<:voice:815827186116198430>"
TextChannel = "<:text:815827264679706624>"
category = "<:category:815831557507776583>"
pain = "<:blobpain:831771526368985098>"
settings_yes = "<:settings_mark_off:815169498319159337><:settings_check_on:815169424566517791>"
settings_no = "<:set_no_on:815169465259786241><:set_yes_off:815169360393404436>"


pstop = "<:stop:829602188593856574>"
pprevious = "<:previous:829602188565151744>"
pnext = "<:next:829602188653101056>"
plast = "<:last:829602188435128331>"
pfirst = "<:first:829602188598312990>"


red1 = "<:red1:870909062227845122>"
red2 = "<:red2:870909062513061899>"
red3 = "<:red3:870909062877966376>"
red4 = "<:red4:870909062341099572>"
red5 = "<:red5:870909062437548072>"


green1 = "<:green1:870909061514792991>"
green2 = "<:green2:870909061225390131>"
green3 = "<:green3:870909061661605969>"
green4 = "<:green4:870909062320099329>"
green5 = "<:green5:870909062345281546>"

BADGES = {
    "creator": "<:creator:807911084069617674>",
    "dev": "<:dev:807911284040531999>",
    "donator": "<a:donator:807913325861142578>",
    "messenger": "<a:messenger:807912019130974242>",
    "premium": "<a:premium:807911675981201459>",
    "contributor": "<a:contributor:807911226432028704>",
    "staff": "<:staff:807911358549065738>",
    "top_user": "<a:top_user:807911932299837460>",
    "voter": "<:voter:807912082142003220>",
}

p = "\U0001f1f5"
e = "\U0001f1ea"
r = "\U0001f1f7"
eye = "👀"
